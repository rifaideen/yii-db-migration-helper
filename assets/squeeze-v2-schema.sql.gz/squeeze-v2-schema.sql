# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.4.6-MariaDB)
# Database: squeeze-v2
# Generation Time: 2019-11-27 05:47:37 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table appointment
# ------------------------------------------------------------

CREATE TABLE `appointment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `knack_id` varchar(128) DEFAULT NULL,
  `booking_ref_id` varchar(128) DEFAULT NULL,
  `timezone` varchar(250) DEFAULT NULL,
  `start_at` datetime DEFAULT NULL,
  `end_at` datetime DEFAULT NULL,
  `is_noshow` tinyint(1) DEFAULT 0,
  `is_charged` tinyint(1) DEFAULT 0,
  `has_tip` tinyint(1) DEFAULT 0,
  `has_review` tinyint(1) DEFAULT 0,
  `points_used` float DEFAULT NULL,
  `points_cancelled` int(11) DEFAULT NULL,
  `code` varchar(128) DEFAULT NULL,
  `reason` varchar(250) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `pressure` varchar(250) DEFAULT NULL,
  `sms_reminder` tinyint(1) DEFAULT 0,
  `user_id` int(11) unsigned NOT NULL,
  `membership_id` int(11) unsigned DEFAULT NULL,
  `location_id` int(11) unsigned NOT NULL,
  `therapist_id` int(11) unsigned NOT NULL,
  `service_id` int(11) unsigned NOT NULL,
  `entity_status_id` int(11) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_membership_id` (`membership_id`),
  KEY `fk_location_id` (`location_id`),
  KEY `fk_user_id` (`user_id`),
  KEY `fk_therapist_id` (`therapist_id`),
  KEY `fk_service_id` (`service_id`),
  KEY `fk_entity_status` (`entity_status_id`),
  CONSTRAINT `fk_entity_status` FOREIGN KEY (`entity_status_id`) REFERENCES `entity_status` (`id`),
  CONSTRAINT `fk_location_id` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `fk_membership_id` FOREIGN KEY (`membership_id`) REFERENCES `membership` (`id`),
  CONSTRAINT `fk_service_id` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`),
  CONSTRAINT `fk_therapist_id` FOREIGN KEY (`therapist_id`) REFERENCES `therapist` (`id`),
  CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table branch_referral
# ------------------------------------------------------------

CREATE TABLE `branch_referral` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referrer_customer_id` int(11) unsigned DEFAULT NULL,
  `referee_customer_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referee_customer_email` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_registration_claimed` tinyint(4) DEFAULT 0,
  `is_booking_claimed` tinyint(4) DEFAULT 0,
  `is_registration_processed` tinyint(4) DEFAULT 0,
  `is_booking_processed` tinyint(4) DEFAULT 0,
  `points` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `referrer_customer_id` (`referrer_customer_id`),
  CONSTRAINT `branch_referral_ibfk_1` FOREIGN KEY (`referrer_customer_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table charge
# ------------------------------------------------------------

CREATE TABLE `charge` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(250) DEFAULT NULL,
  `charge_ref_id` varchar(128) DEFAULT NULL,
  `original_amount` float DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `charged_amount` float DEFAULT NULL,
  `cancelled_amount` float DEFAULT NULL,
  `entity_type` varchar(250) DEFAULT NULL,
  `entity_id` int(11) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table config
# ------------------------------------------------------------

CREATE TABLE `config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table coupon
# ------------------------------------------------------------

CREATE TABLE `coupon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` float DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table delayed_email
# ------------------------------------------------------------

CREATE TABLE `delayed_email` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `to` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `response` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `send_date` datetime NOT NULL,
  `type` smallint(5) unsigned DEFAULT NULL,
  `sent` smallint(5) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table entity_status
# ------------------------------------------------------------

CREATE TABLE `entity_status` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `entity_type` varchar(250) DEFAULT NULL COMMENT 'name of the table it refers to',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `entity_status` WRITE;
/*!40000 ALTER TABLE `entity_status` DISABLE KEYS */;

INSERT INTO `entity_status` (`id`, `name`, `description`, `entity_type`)
VALUES
	(1,'active','Active Membership','membership'),
	(2,'paused','Paused Membership','membership'),
	(3,'cancelled','Cancelled Membership','membership'),
	(4,'points','Points Membership','membership'),
	(5,'expired','Membership Expired','membership'),
	(6,'booked','Appointment Booked','appointment'),
	(7,'complete','Appointment Complete','appointment'),
	(8,'cancelled','Appointment Cancelled','appointment'),
	(9,'confirmed','Appointment Confirmed','appointment'),
	(10,'checked-in','Appointment Checked In','appointment');

/*!40000 ALTER TABLE `entity_status` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table favourite_therapist
# ------------------------------------------------------------

CREATE TABLE `favourite_therapist` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `therapist_id` int(11) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customer_id` (`user_id`),
  KEY `therapist_id` (`therapist_id`),
  CONSTRAINT `favourite_therapist_ibfk_1` FOREIGN KEY (`therapist_id`) REFERENCES `therapist` (`id`),
  CONSTRAINT `fk_customer_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table gifting_email
# ------------------------------------------------------------

CREATE TABLE `gifting_email` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `send_type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_sent` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `gifting_transaction_id` int(11) unsigned NOT NULL,
  `sender_customer_id` int(11) unsigned NOT NULL,
  `sender_customer_name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sender_customer_email` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient_name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient_email` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street1` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street2` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT 'US',
  `delivery_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gifting_transaction_id` (`gifting_transaction_id`),
  KEY `sender_customer_id` (`sender_customer_id`),
  CONSTRAINT `gifting_email_ibfk_1` FOREIGN KEY (`gifting_transaction_id`) REFERENCES `gifting_transaction` (`id`),
  CONSTRAINT `gifting_email_ibfk_2` FOREIGN KEY (`sender_customer_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table gifting_transaction
# ------------------------------------------------------------

CREATE TABLE `gifting_transaction` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `knack_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `giftcard_code` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_date` timestamp NULL DEFAULT NULL,
  `status` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_charged` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `charge_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_ref_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `membership_length` float DEFAULT NULL,
  `sender_id` int(11) unsigned NOT NULL,
  `sender_has_membership` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiver_id` int(11) unsigned DEFAULT NULL,
  `request` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `response` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charged_at` datetime DEFAULT NULL,
  `redeemed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `receiver_id` (`receiver_id`),
  CONSTRAINT `gifting_transaction_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `user` (`id`),
  CONSTRAINT `gifting_transaction_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table location
# ------------------------------------------------------------

CREATE TABLE `location` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `knack_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_ref_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT 'America/Los_Angeles',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'US',
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lat` decimal(10,8) DEFAULT NULL,
  `lang` decimal(11,8) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `coming_soon_message` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hours` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `locations_booker_location_id_unique` (`service_ref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table massage_type
# ------------------------------------------------------------

CREATE TABLE `massage_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialization_type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT 'false',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table membership
# ------------------------------------------------------------

CREATE TABLE `membership` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `stripe_product_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_subscription_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_coupon` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_plan_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `giftcard_update_plan_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` float DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `next_start_date` datetime DEFAULT NULL,
  `pause_date` datetime DEFAULT NULL,
  `resume_pause_date` datetime DEFAULT NULL,
  `cancel_date` datetime DEFAULT NULL,
  `cancel_reason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resume_date` datetime DEFAULT NULL,
  `is_charged` tinyint(1) DEFAULT 0,
  `charge_status` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charge_amount` float NOT NULL DEFAULT 0,
  `discount_amount` float NOT NULL DEFAULT 0,
  `cancelled_amount` float NOT NULL DEFAULT 0,
  `user_id` int(11) unsigned NOT NULL,
  `location_id` int(11) unsigned NOT NULL,
  `membership_type_id` int(11) unsigned NOT NULL,
  `entity_status_id` int(11) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `location_id` (`location_id`),
  KEY `entity_status_id` (`entity_status_id`),
  KEY `membership_type_id` (`membership_type_id`),
  CONSTRAINT `membership_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `membership_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `membership_ibfk_4` FOREIGN KEY (`entity_status_id`) REFERENCES `entity_status` (`id`),
  CONSTRAINT `membership_ibfk_5` FOREIGN KEY (`membership_type_id`) REFERENCES `membership_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table membership_points_transactions
# ------------------------------------------------------------

CREATE TABLE `membership_points_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spabooker_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_number` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points_difference` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remaining_points` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `membership_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_subscription_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_charged` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `charge_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charge_status` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charge_amount` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `discount_amount` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `cancelled_amount` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `code` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points_used` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `notes` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table membership_transaction
# ------------------------------------------------------------

CREATE TABLE `membership_transaction` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `membership_id` int(11) unsigned NOT NULL,
  `appointment_id` int(11) unsigned DEFAULT NULL COMMENT 'If appointment involved',
  `points_used` float unsigned DEFAULT NULL,
  `points_left` float unsigned DEFAULT NULL COMMENT 'points left before this transaction',
  `points_awarded` float unsigned DEFAULT NULL,
  `points_deducted` float DEFAULT NULL,
  `notes` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL COMMENT 'i.e spent, adjustment',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `membership_id` (`membership_id`),
  KEY `appointment_id` (`appointment_id`),
  CONSTRAINT `membership_transaction_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `membership_transaction_ibfk_2` FOREIGN KEY (`membership_id`) REFERENCES `membership` (`id`),
  CONSTRAINT `membership_transaction_ibfk_3` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table membership_type
# ------------------------------------------------------------

CREATE TABLE `membership_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `benefit` float DEFAULT NULL,
  `type` enum('paid','promotional','both') DEFAULT NULL,
  `origin` varchar(250) DEFAULT NULL COMMENT 'i.e membership, gift card, guest satisfaction or RAF award',
  `location_id` int(11) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `membership_type_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `membership_type` WRITE;
/*!40000 ALTER TABLE `membership_type` DISABLE KEYS */;

INSERT INTO `membership_type` (`id`, `name`, `description`, `price`, `benefit`, `type`, `origin`, `location_id`, `created_at`, `updated_at`)
VALUES
	(1,'Main','Main Membership',99,79,'paid',NULL,1,NULL,NULL),
	(2,'Mid','Mid Membership',79,59,'paid',NULL,1,NULL,NULL),
	(3,'Points','Points (Membership)',NULL,NULL,'both','Guest satisfaction via Knack or Gift card remainder deposit or RAF award',1,NULL,NULL);

/*!40000 ALTER TABLE `membership_type` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table notification
# ------------------------------------------------------------

CREATE TABLE `notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_sent` tinyint(1) DEFAULT 0,
  `user_id` int(11) unsigned DEFAULT NULL,
  `phone` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_id` int(11) unsigned DEFAULT NULL,
  `start_date_time` datetime DEFAULT NULL,
  `end_date_time` datetime DEFAULT NULL,
  `booker_service_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pressure_requirement` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pregnant` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender_preference` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `therapist_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_subscription` tinyint(1) DEFAULT NULL,
  `plan` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`user_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `notification_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table password_resets
# ------------------------------------------------------------

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table preference
# ------------------------------------------------------------

CREATE TABLE `preference` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `key` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `preference_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table review
# ------------------------------------------------------------

CREATE TABLE `review` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `knack_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knack_approved` smallint(6) DEFAULT 0,
  `therapist_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `appointment_id` int(11) unsigned DEFAULT NULL,
  `rating` smallint(5) unsigned DEFAULT 0,
  `favorite` smallint(6) DEFAULT 0,
  `share_public` smallint(6) DEFAULT 0,
  `share_therapist` smallint(6) DEFAULT 0,
  `comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `private_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `therapist_id` (`therapist_id`),
  KEY `user_id` (`user_id`),
  KEY `appointment_id` (`appointment_id`),
  CONSTRAINT `review_ibfk_1` FOREIGN KEY (`therapist_id`) REFERENCES `therapist` (`id`),
  CONSTRAINT `review_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `review_ibfk_3` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table service
# ------------------------------------------------------------

CREATE TABLE `service` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `service_ref_id` varchar(128) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `label` varchar(250) DEFAULT NULL,
  `subtitle` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `member_price` float DEFAULT NULL,
  `non_member_price` float DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `subscription_price` float DEFAULT NULL,
  `location_id` int(11) unsigned DEFAULT NULL COMMENT 'price to be changed based on location',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `service_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table stripe_transaction
# ------------------------------------------------------------

CREATE TABLE `stripe_transaction` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `charge_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `stripe_customer_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`user_id`),
  CONSTRAINT `stripe_transaction_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table therapist
# ------------------------------------------------------------

CREATE TABLE `therapist` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `knack_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_ref_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'underlying service unique ref id',
  `service_type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT 'Scheduled' COMMENT 'i.e schedules, freelancer',
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT 0,
  `bio` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_url` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pregnancy` tinyint(1) NOT NULL DEFAULT 0,
  `average_rating` double(3,2) DEFAULT NULL,
  `average_rating_count` smallint(5) unsigned DEFAULT 0,
  `admin_labor_rate` decimal(10,4) DEFAULT NULL,
  `massage_labor_rate` decimal(10,4) DEFAULT NULL,
  `license_expiration` datetime DEFAULT NULL,
  `license_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_id` int(11) unsigned NOT NULL,
  `is_deleted` tinyint(1) unsigned DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `therapist_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table therapist_massage_type
# ------------------------------------------------------------

CREATE TABLE `therapist_massage_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `therapist_id` int(10) unsigned NOT NULL,
  `massage_type_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `therapist_massage_types_therapist_id_foreign` (`therapist_id`),
  KEY `therapist_massage_types_massage_type_id_foreign` (`massage_type_id`),
  CONSTRAINT `therapist_massage_types_massage_type_id_foreign` FOREIGN KEY (`massage_type_id`) REFERENCES `massage_type` (`id`),
  CONSTRAINT `therapist_massage_types_therapist_id_foreign` FOREIGN KEY (`therapist_id`) REFERENCES `therapist` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table therapist_service
# ------------------------------------------------------------

CREATE TABLE `therapist_service` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_id` int(10) unsigned NOT NULL,
  `therapist_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `therapist_services_service_id_foreign` (`service_id`),
  KEY `therapist_services_therapist_id_foreign` (`therapist_id`),
  CONSTRAINT `therapist_services_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`),
  CONSTRAINT `therapist_services_therapist_id_foreign` FOREIGN KEY (`therapist_id`) REFERENCES `therapist` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table tips
# ------------------------------------------------------------

CREATE TABLE `tips` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appointment_id` int(11) unsigned DEFAULT NULL,
  `therapist_id` int(11) unsigned DEFAULT NULL,
  `is_charged` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `charge_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `appointment_id` (`appointment_id`),
  KEY `therapist_id` (`therapist_id`),
  CONSTRAINT `tips_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`id`),
  CONSTRAINT `tips_ibfk_2` FOREIGN KEY (`therapist_id`) REFERENCES `therapist` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table user
# ------------------------------------------------------------

CREATE TABLE `user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `knack_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spabooker_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_id` int(11) unsigned DEFAULT NULL,
  `is_failed` tinyint(4) DEFAULT 0,
  `stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date NOT NULL,
  `push_notifications` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `device_id` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reminder_opt_in` smallint(6) NOT NULL DEFAULT 0,
  `has_membership` tinyint(4) DEFAULT 0,
  `is_refer_a_friend` smallint(5) unsigned DEFAULT 0,
  `heard_about_us` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vi_squeeze` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `refer_a_friend_nudge` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refer_a_friend_nudge_date` datetime DEFAULT NULL,
  `appstore_rating_nudge` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appstore_rating_nudge_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table webhook
# ------------------------------------------------------------

CREATE TABLE `webhook` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `event` varchar(250) DEFAULT NULL,
  `sender` varchar(128) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  `request` text DEFAULT NULL,
  `params` text DEFAULT NULL,
  `status` varchar(128) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
